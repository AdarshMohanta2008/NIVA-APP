import React from 'react';
import { motion } from 'motion/react';
import { Home, Calendar, ShoppingBag, PlaySquare, User, Disc3, BookOpen } from 'lucide-react';
import { Religion } from '../types';
import { DIVINE_THEMES } from '../theme/divineThemes';
import { useEffectsSettings } from '../context/EffectsContext';

export type TabType = 'home' | 'calendar' | 'books' | 'music' | 'shop' | 'reels' | 'profile';

interface BottomNavProps {
  activeTab: TabType;
  onChangeTab: (tab: TabType) => void;
  cartCount: number;
  isMusicPlaying?: boolean;
  currentReligion?: Religion;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  cartCount,
  isMusicPlaying = false,
  currentReligion = 'All',
}) => {
  const activeTheme = DIVINE_THEMES[currentReligion] || DIVINE_THEMES.All;
  const { effectsLevel } = useEffectsSettings();

  const tabs = [
    { id: 'home' as TabType, label: 'Home', icon: Home },
    { id: 'calendar' as TabType, label: 'Calendar', icon: Calendar },
    { id: 'books' as TabType, label: 'Books', icon: BookOpen },
    { id: 'music' as TabType, label: 'Music', icon: Disc3, isMusic: true },
    { id: 'shop' as TabType, label: 'Shop', icon: ShoppingBag, badge: cartCount },
    { id: 'reels' as TabType, label: 'Reels', icon: PlaySquare },
    { id: 'profile' as TabType, label: 'Profile', icon: User },
  ];

  return (
    <aside className="hidden lg:flex shrink-0 w-64 xl:w-72 flex-col h-full p-4 z-40 pointer-events-auto">
      <div className="glass-panel flex-1 flex flex-col p-3 border border-white/15 overflow-y-auto">
        <div className="flex items-center gap-3 px-3 py-4 mb-2">
          <img
            src="/src/assets/images/niva_avatar_insignia_1790479243016.jpg"
            alt="NIVA"
            className="w-10 h-10 rounded-full object-cover border border-white/40"
          />
          <span className="font-brand text-xl font-bold tracking-widest gradient-text-sacred">NIVA</span>
        </div>
        <div className="flex flex-col gap-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`nav-tab-${tab.id}`}
                onClick={() => onChangeTab(tab.id)}
                className="relative flex items-center gap-3 px-4 py-3 rounded-2xl transition-all cursor-pointer group text-left"
              >
                {isActive && (
                  <motion.div
                    layoutId="activeSidebarPill"
                    transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                    className="absolute inset-0 rounded-2xl bg-white/[0.14] border border-white/30 shadow-[inset_0_1px_1px_rgba(255,255,255,0.35),0_0_20px_rgba(168,85,247,0.3)]"
                  />
                )}
                <Icon
                  className={`relative z-10 w-5 h-5 transition-colors ${
                    isActive ? '' : 'text-white/60 group-hover:text-white/90'
                  } ${tab.isMusic && isMusicPlaying ? 'animate-spin' : ''}`}
                  style={{
                    color: isActive ? activeTheme.accentColor : undefined,
                    filter: isActive ? `drop-shadow(0 0 8px ${activeTheme.accentGlow})` : 'none',
                  }}
                />
                <span
                  className={`relative z-10 text-sm tracking-tight ${
                    isActive ? 'text-white font-semibold' : 'text-white/60 group-hover:text-white/90 font-medium'
                  }`}
                >
                  {tab.label}
                </span>
                {Boolean(tab.badge && tab.badge > 0) && (
                  <span className="relative z-10 ml-auto text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] px-1 flex items-center justify-center bg-gradient-to-r from-purple-500 to-amber-500">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </aside>
  );
};

/** Compact tab strip shown only on narrow screens (below lg) */
export const TopTabsNarrow: React.FC<BottomNavProps> = ({ activeTab, onChangeTab }) => {
  const items: { id: TabType; label: string }[] = [
    { id: 'home', label: 'Home' }, { id: 'calendar', label: 'Calendar' }, { id: 'books', label: 'Books' },
    { id: 'music', label: 'Music' }, { id: 'shop', label: 'Shop' }, { id: 'reels', label: 'Reels' }, { id: 'profile', label: 'Profile' },
  ];
  return (
    <div className="lg:hidden flex gap-1 overflow-x-auto no-scrollbar px-4 pb-2">
      {items.map((t) => (
        <button
          key={t.id}
          onClick={() => onChangeTab(t.id)}
          className={`px-3.5 py-1.5 rounded-full text-xs font-semibold shrink-0 cursor-pointer border ${
            activeTab === t.id ? 'bg-white/15 border-white/30 text-white' : 'border-white/10 text-white/60'
          }`}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
};
