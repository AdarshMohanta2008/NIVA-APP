import React from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface LightBurstProps {
  isActive: boolean;
  color?: string;
  onComplete?: () => void;
}

export const LightBurst: React.FC<LightBurstProps> = ({
  isActive,
  color = '#F59E0B',
  onComplete,
}) => {
  return (
    <AnimatePresence>
      {isActive && (
        <motion.div
          initial={{ opacity: 0, scale: 0.1 }}
          animate={{ opacity: [0, 1, 0.9, 0], scale: [0.1, 1.5, 3, 5] }}
          transition={{ duration: 0.85, ease: [0.22, 1, 0.36, 1] }}
          onAnimationComplete={onComplete}
          className="fixed inset-0 pointer-events-none z-50 flex items-center justify-center overflow-hidden"
          aria-hidden="true"
        >
          {/* Central Warp Bloom */}
          <div
            className="w-96 h-96 rounded-full"
            style={{
              background: `radial-gradient(circle, #FFFFFF 0%, ${color} 40%, rgba(168, 85, 247, 0.5) 70%, transparent 100%)`,
              filter: 'blur(30px)',
            }}
          />
          {/* Expanding Light Ring */}
          <motion.div
            initial={{ opacity: 0.8, scale: 0.2 }}
            animate={{ opacity: 0, scale: 4 }}
            transition={{ duration: 0.85, ease: 'easeOut' }}
            className="absolute w-[500px] h-[500px] rounded-full border-2 border-white/80"
            style={{
              boxShadow: `0 0 60px ${color}`,
            }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
};
